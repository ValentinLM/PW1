import React, { Component } from 'react';

class LightningCounter extends React.Component{
            constructor(props, context){
                super(props, context);
                
                this.state = {
                    segundos: 0,
                    minutos: 0,
                    horas:0
                };
                
                this.timerTick = this.timerTick.bind(this);
            }
            
            timerTick(){
                var nuevosSegundos = this.state.segundos+1;
                var nuevosMinutos = this.state.minutos;
                var nuevasHoras = this.state.horas;
                if(this.state.segundos>58){
                    nuevosSegundos = 0;
                    nuevosMinutos = this.state.minutos+1;
                }
                
                if(this.state.minutos>58){
                    nuevosMinutos = 0;
                    nuevasHoras = this.state.horas + 1;
                }
                    
                this.setState({
                    segundos: nuevosSegundos,
                    minutos: nuevosMinutos,
                    horas: nuevasHoras
                });
            }
            
            componentDidMount(){
                setInterval(this.timerTick, 1000);
            }
            render(){
                return (
                    <h1>{this.state.horas}:{this.state.minutos}:{this.state.segundos}</h1>
                );
            }
        }
        
        class Cronometro extends React.Component{
            render(){
                var divStyle = {
                    width: 250,
                    textAlign: "center",
                    backgroundColor: "white",
                    padding: 40,
                    fontFamily: "sans-serif",
                    color: "#1c1515",
                    borderRadius: 10
                };
                
                return(
                    <div style= {divStyle}>
                        <LightningCounter/>
                    </div>
                );
            }
        }

export default Cronometro;